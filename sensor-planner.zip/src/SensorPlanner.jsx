import React, { useState, useRef, useEffect, useCallback } from "react";

const CONSTANTS = {
  MARGIN: 50,
  CANVAS_WIDTH: 900,
  CANVAS_HEIGHT: 900,
  SNAP_THRESHOLD: 30,
  SENSOR_RADIUS: 20,
  TOUCH_TARGET: 38,
  MIN_RANGE: 8,
  MAX_RANGE: 12,
  DETECTION_ANGLE: 80, // zie Hue docs
  SENSOR_COLORS: [
    { color: "#00a0ff", name: "Blauw" },
    { color: "#ff6b00", name: "Oranje" },
    { color: "#00cc66", name: "Groen" },
    { color: "#ff3366", name: "Rood" },
    { color: "#9933ff", name: "Paars" },
    { color: "#ffcc00", name: "Geel" },
  ],
  MOUNT_OPTIONS: [
    { angle: 0, name: "Naar rechts →" },
    { angle: 45, name: "Hoek rechts-onder ↘" },
    { angle: 90, name: "Naar beneden ↓" },
    { angle: 135, name: "Hoek links-onder ↙" },
    { angle: 180, name: "Naar links ←" },
    { angle: 225, name: "Hoek links-boven ↖" },
    { angle: 270, name: "Naar boven ↑" },
    { angle: 315, name: "Hoek rechts-boven ↗" },
  ],
};

const TUIN = {
  breedte: 5.7,      // meter, zie tekening
  lengte: 16.51,     // meter, linkerzijde tot voorste punt
  schuur: { x: 5.7 - 2.0, y: 0, w: 2.0, h: 2.0 }, // schuurblok
};

function SensorPlanner() {
  const [dimensions] = useState({
    width: TUIN.breedte,
    length: TUIN.lengte,
  });

  const getIdealSensorPositions = useCallback(() => {
    const pixelsPerMeter = (CONSTANTS.CANVAS_WIDTH - 2 * CONSTANTS.MARGIN) / dimensions.width;
    const M = CONSTANTS.MARGIN;
    return [
      {
        id: 1,
        name: "Sensor 1 (achterhoek links)",
        position: { x: M, y: M },
        rotation: 45,
        color: CONSTANTS.SENSOR_COLORS[0].color,
        visible: true,
        range: CONSTANTS.MAX_RANGE,
        wallId: "corner-backleft",
      },
      {
        id: 2,
        name: "Sensor 2 (zijmuur voor)",
        position: { x: M, y: M + (dimensions.length - 2) * pixelsPerMeter },
        rotation: 90,
        color: CONSTANTS.SENSOR_COLORS[1].color,
        visible: true,
        range: CONSTANTS.MAX_RANGE,
        wallId: "sidewall-front",
      },
      {
        id: 3,
        name: "Sensor 3 (hoek schuur/achter)",
        position: { x: M + (dimensions.width - 2) * pixelsPerMeter, y: M },
        rotation: 135,
        color: CONSTANTS.SENSOR_COLORS[2].color,
        visible: false,
        range: CONSTANTS.MAX_RANGE,
        wallId: "corner-schuur",
      },
    ];
  }, [dimensions]);

  const [sensors, setSensors] = useState(getIdealSensorPositions());
  const [selectedSensorId, setSelectedSensorId] = useState(1);
  const [isDragging, setIsDragging] = useState(false);
  const [showCoverage, setShowCoverage] = useState(true);
  const canvasRef = useRef(null);
  const selectedSensor = sensors.find((s) => s.id === selectedSensorId);

  const getPixelsPerMeter = useCallback(() => {
    const usableWidth = CONSTANTS.CANVAS_WIDTH - 2 * CONSTANTS.MARGIN;
    return usableWidth / dimensions.width;
  }, [dimensions.width]);

  const getWalls = useCallback((ppm) => {
    const M = CONSTANTS.MARGIN;
    const tuinW = dimensions.width * ppm;
    const tuinH = dimensions.length * ppm;
    return [
      { id: "left", x: M, start: M, end: M + tuinH, isVertical: true, type: "fence" },
      { id: "right", x: M + tuinW, start: M, end: M + tuinH, isVertical: true, type: "fence" },
      { id: "top", y: M, start: M, end: M + tuinW, isHorizontal: true, type: "fence" },
      { id: "bottom", y: M + tuinH, start: M, end: M + tuinW, isHorizontal: true, type: "fence" },
      { id: "corner-backleft", x: M, y: M, isCorner: true, type: "corner" },
      { id: "corner-backright", x: M + tuinW, y: M, isCorner: true, type: "corner" },
      { id: "corner-frontleft", x: M, y: M + tuinH, isCorner: true, type: "corner" },
      { id: "corner-frontright", x: M + tuinW, y: M + tuinH, isCorner: true, type: "corner" },
      { id: "sidewall-front", x: M, y: M + tuinH - 2 * ppm, isCorner: true, type: "corner" },
      { id: "corner-schuur", x: M + (dimensions.width - 2) * ppm, y: M, isCorner: true, type: "corner" },
    ];
  }, [dimensions]);

  const snapToWall = useCallback((x, y) => {
    const ppm = getPixelsPerMeter();
    const walls = getWalls(ppm);
    let closest = null;
    let snapped = { x, y };
    let minDist = CONSTANTS.SNAP_THRESHOLD;

    walls.filter((w) => w.isCorner).forEach((corner) => {
      const dist = Math.hypot(x - corner.x, y - corner.y);
      if (dist < minDist * 1.7) {
        minDist = dist;
        closest = corner;
        snapped = { x: corner.x, y: corner.y, wallId: corner.id };
      }
    });
    if (!closest) {
      walls.filter((w) => !w.isCorner).forEach((wall) => {
        if (wall.isVertical) {
          const dist = Math.abs(x - wall.x);
          if (dist < minDist && y >= wall.start && y <= wall.end) {
            minDist = dist;
            closest = wall;
            snapped = { x: wall.x, y: y, wallId: wall.id };
          }
        } else {
          const dist = Math.abs(y - wall.y);
          if (dist < minDist && x >= wall.start && x <= wall.end) {
            minDist = dist;
            closest = wall;
            snapped = { x: x, y: wall.y, wallId: wall.id };
          }
        }
      });
    }
    return snapped;
  }, [getPixelsPerMeter, getWalls]);

  const getSuggestedRotation = (wallId) => {
    const rotations = {
      "left": 0,
      "right": 180,
      "top": 90,
      "bottom": 270,
      "corner-backleft": 45,
      "corner-backright": 135,
      "corner-frontleft": 315,
      "corner-frontright": 225,
      "sidewall-front": 90,
      "corner-schuur": 135,
    };
    return rotations[wallId] || 0;
  };

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const ppm = getPixelsPerMeter();
    ctx.clearRect(0, 0, CONSTANTS.CANVAS_WIDTH, CONSTANTS.CANVAS_HEIGHT);

    ctx.fillStyle = "#f3f3f3";
    ctx.fillRect(CONSTANTS.MARGIN, CONSTANTS.MARGIN, dimensions.width * ppm, dimensions.length * ppm);

    ctx.fillStyle = "#e8f5e8";
    ctx.fillRect(CONSTANTS.MARGIN, CONSTANTS.MARGIN, dimensions.width * ppm, 6 * ppm);

    ctx.fillStyle = "#d3bfa5";
    ctx.fillRect(
      CONSTANTS.MARGIN + TUIN.schuur.x * ppm,
      CONSTANTS.MARGIN + TUIN.schuur.y * ppm,
      TUIN.schuur.w * ppm,
      TUIN.schuur.h * ppm
    );
    ctx.fillStyle = "#333";
    ctx.font = "14px Arial";
    ctx.fillText("Schuur", CONSTANTS.MARGIN + (TUIN.schuur.x + 0.3) * ppm, CONSTANTS.MARGIN + (TUIN.schuur.h / 2) * ppm);

    const walls = getWalls(ppm).filter((w) => !w.isCorner);
    ctx.strokeStyle = "#9e7748";
    ctx.lineWidth = 10;
    ctx.setLineDash([]);
    walls.forEach((wall) => {
      ctx.beginPath();
      if (wall.isVertical) {
        ctx.moveTo(wall.x, wall.start);
        ctx.lineTo(wall.x, wall.end);
      } else {
        ctx.moveTo(wall.start, wall.y);
        ctx.lineTo(wall.end, wall.y);
      }
      ctx.stroke();
    });

    const corners = getWalls(ppm).filter((w) => w.isCorner);
    corners.forEach((corner) => {
      ctx.beginPath();
      ctx.fillStyle = "rgba(255, 204, 0, 0.30)";
      ctx.arc(corner.x, corner.y, 32, 0, 2 * Math.PI);
      ctx.fill();
      ctx.strokeStyle = "#ffcc00";
      ctx.lineWidth = 4;
      ctx.setLineDash([7, 5]);
      ctx.stroke();
    });

    sensors.forEach((sensor) => {
      if (!sensor.visible) return;
      const angle = (sensor.rotation || 0) * Math.PI / 180;
      const startAngle = angle - (CONSTANTS.DETECTION_ANGLE / 2) * Math.PI / 180;
      const endAngle = angle + (CONSTANTS.DETECTION_ANGLE / 2) * Math.PI / 180;

      if (showCoverage) {
        ctx.beginPath();
        ctx.moveTo(sensor.position.x, sensor.position.y);
        ctx.arc(sensor.position.x, sensor.position.y, sensor.range * ppm, startAngle, endAngle);
        ctx.lineTo(sensor.position.x, sensor.position.y);
        ctx.fillStyle = sensor.color + "22";
        ctx.fill();
      }
      ctx.fillStyle = "#333";
      ctx.fillRect(sensor.position.x - 12, sensor.position.y - 12, 24, 24);

      ctx.beginPath();
      ctx.arc(sensor.position.x, sensor.position.y, CONSTANTS.SENSOR_RADIUS, 0, 2 * Math.PI);
      ctx.fillStyle = sensor.color;
      ctx.fill();
      if (sensor.id === selectedSensorId) {
        ctx.strokeStyle = "#fff";
        ctx.lineWidth = 4;
        ctx.stroke();
      }
      const l = CONSTANTS.SENSOR_RADIUS * 2;
      ctx.beginPath();
      ctx.moveTo(sensor.position.x, sensor.position.y);
      ctx.lineTo(sensor.position.x + l * Math.cos(angle), sensor.position.y + l * Math.sin(angle));
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 3;
      ctx.stroke();
      ctx.font = "12px Arial";
      ctx.fillStyle = "#fff";
      ctx.fillText(sensor.name, sensor.position.x + 18, sensor.position.y - 10);
    });

    ctx.setLineDash([]);
    ctx.font = "15px Arial";
    ctx.fillStyle = "#666";
    ctx.fillText(`${dimensions.width}m`, CONSTANTS.MARGIN + (dimensions.width * ppm) / 2, CONSTANTS.MARGIN - 18);
    ctx.save();
    ctx.translate(CONSTANTS.MARGIN - 35, CONSTANTS.MARGIN + (dimensions.length * ppm) / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText(`${dimensions.length}m`, 0, 0);
    ctx.restore();
  }, [sensors, selectedSensorId, showCoverage, dimensions, getPixelsPerMeter, getWalls]);

  useEffect(() => {
    draw();
  }, [draw]);

  // (De rest van de code: drag, sensor controls, etc. kun je toevoegen naar wens)

  return (
    <div style={{ maxWidth: "920px", margin: "auto", background: "#fafafa", borderRadius: "15px", padding: "28px" }}>
      <h2 style={{ fontSize: 28, fontWeight: 700, textAlign: "center", marginBottom: 6 }}>🏠 Realistische Tuin Sensorplanner</h2>
      <canvas
        ref={canvasRef}
        width={CONSTANTS.CANVAS_WIDTH}
        height={CONSTANTS.CANVAS_HEIGHT}
        style={{
          width: "100%",
          border: "2px solid #c5c5c5",
          borderRadius: 10,
          marginBottom: 24,
          background: "#f9f9f9",
        }}
      />
      <div style={{ margin: "auto", maxWidth: 600 }}>
        <p>
          <b>Sleep</b> sensoren naar een hoek of muur.<br />
          <b>Gele cirkels</b>: ideale plekken volgens Hue-instructies.<br />
          <b>Let op:</b> Voor optimale detectie: 1.5 - 2.5m hoog, 8-12m bereik, 80° detectiehoek.<br />
          <b>Jouw tuin:</b> {dimensions.width}m x {dimensions.length}m
        </p>
      </div>
    </div>
  );
}

export default SensorPlanner;
