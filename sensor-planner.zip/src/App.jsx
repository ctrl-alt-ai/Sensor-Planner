import React from "react";
import SensorPlanner from "./SensorPlanner";

export default function App() {
  return (
    <div style={{ minHeight: "100vh", background: "#f3f4f7" }}>
      <SensorPlanner />
    </div>
  );
}
